"""
SMS Gateway abstraction.
─────────────────────────────────────────────────────────────
Currently uses a STUB that just logs to console.
To plug in a real provider (e.g. MSG91, Textlocal, Fast2SMS):
  1. pip install requests  (already available)
  2. Replace `_send_stub` with your provider's HTTP call.
  3. Set credentials in settings.py:
       SMS_GATEWAY_API_KEY = 'your-key'
       SMS_GATEWAY_SENDER  = 'GRAMPN'
─────────────────────────────────────────────────────────────
"""

import logging
from django.conf import settings

logger = logging.getLogger(__name__)


def send_sms(phone: str, message: str) -> dict:
    """
    Returns {'success': bool, 'response': str}
    """
    # ── Choose provider based on settings ────────────────────────────────
    provider = getattr(settings, "SMS_GATEWAY_PROVIDER", "stub")

    if provider == "fast2sms":
        return _send_fast2sms(phone, message)
    if provider == "msg91":
        return _send_msg91(phone, message)
    # default
    return _send_stub(phone, message)


# ── STUB (no real sending) ────────────────────────────────────────────────


def _send_stub(phone: str, message: str) -> dict:
    logger.info(f"[SMS STUB] TO={phone}  MSG={message[:60]}…")
    print(f"\n📱 [SMS STUB] → {phone}\n{message}\n")
    return {"success": True, "response": "stub:ok"}


# ── Fast2SMS (India) ──────────────────────────────────────────────────────


def _send_fast2sms(phone: str, message: str) -> dict:
    import requests

    api_key = getattr(settings, "SMS_GATEWAY_API_KEY", "")
    try:
        r = requests.post(
            "https://www.fast2sms.com/dev/bulkV2",
            headers={"authorization": api_key},
            data={
                "route": "q",
                "message": message,
                "language": "unicode",  # supports Marathi/Devanagari
                "flash": 0,
                "numbers": phone,
            },
            timeout=10,
        )
        data = r.json()
        ok = data.get("return", False)
        return {"success": ok, "response": str(data)}
    except Exception as e:
        logger.error(f"Fast2SMS error: {e}")
        return {"success": False, "response": str(e)}


# ── MSG91 ─────────────────────────────────────────────────────────────────


def _send_msg91(phone: str, message: str) -> dict:
    import requests

    api_key = getattr(settings, "SMS_GATEWAY_API_KEY", "")
    sender = getattr(settings, "SMS_GATEWAY_SENDER", "GRAMPN")
    try:
        r = requests.post(
            "https://api.msg91.com/api/v5/flow/",
            headers={"authkey": api_key, "Content-Type": "application/json"},
            json={
                "sender": sender,
                "route": "4",
                "country": "91",
                "sms": [{"message": message, "to": [phone]}],
            },
            timeout=10,
        )
        data = r.json()
        ok = data.get("type") == "success"
        return {"success": ok, "response": str(data)}
    except Exception as e:
        logger.error(f"MSG91 error: {e}")
        return {"success": False, "response": str(e)}
